package com.example.screentranslator

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val captureRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 32)
            setBackgroundColor(0xFFF5F6FA.toInt())
        }

        val title = TextView(this).apply {
            text = "Переводчик экрана"
            textSize = 26f
            setTextColor(0xFF172033.toInt())
        }
        val description = TextView(this).apply {
            text = "Перевод английского текста на русский поверх других приложений. " +
                "Распознавание выполняется на устройстве. Для начала разрешите показ поверх окон, " +
                "затем нажмите «Запустить перевод» и подтвердите захват экрана."
            textSize = 16f
            setTextColor(0xFF48536A.toInt())
            setPadding(0, 20, 0, 24)
        }
        val start = Button(this).apply {
            text = "Запустить перевод"
            setOnClickListener { startTranslation() }
        }
        val stop = Button(this).apply {
            text = "Остановить перевод"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenCaptureService::class.java))
                Toast.makeText(this@MainActivity, "Перевод остановлен", Toast.LENGTH_SHORT).show()
            }
        }

        layout.addView(title)
        layout.addView(description)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }

    private fun startTranslation() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(this, "Разрешите отображение поверх других приложений, затем нажмите запуск ещё раз", Toast.LENGTH_LONG).show()
            return
        }

        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
            else startService(serviceIntent)
            Toast.makeText(this, "Перевод запущен", Toast.LENGTH_SHORT).show()
        }
    }
}
